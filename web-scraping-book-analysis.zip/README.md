# Web Scraping and Book Price Analysis

## Project Overview
This project scrapes book information from Books to Scrape,
cleans the dataset, analyzes book prices and ratings,
and creates visualizations.

## Objectives
- Collect book titles, prices, ratings and availability.
- Store scraped data in CSV format.
- Clean and validate the dataset.
- Analyze prices and ratings.
- Generate charts.

## Technologies Used
- Python
- Requests
- Beautiful Soup
- Pandas
- Matplotlib
- Google Colab

## Dataset Columns
- title
- price_gbp
- rating
- availability
- product_url

## Project Structure
- web_scraping_book_analysis.ipynb
- data/books_dataset.csv
- data/books_cleaned.csv
- charts/price_distribution.png
- charts/price_by_rating.png
- requirements.txt

## Data Source
https://books.toscrape.com/

Books to Scrape is a practice website for web scraping.

## How to Run
1. Open the notebook in Google Colab.
2. Install the required libraries.
3. Run each code cell from top to bottom.
4. Review the generated CSV files and charts.

## Results
The notebook generates a book dataset, cleaned data,
summary statistics, and price analysis charts.

## Limitations
Results depend on the website content at the time of scraping.

## License
For educational purposes.
